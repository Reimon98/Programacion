package UT3Métodos;

public class Ejercicio3 {
	static int multiplicacion (int num1, int num2)
	{
		return (num1*num2);
	}

	public static void main(String[] args) {
		int num1=2;
		int num2=2;
		int resultado = multiplicacion(num1,num2);
		System.out.println(resultado);

	}

}
