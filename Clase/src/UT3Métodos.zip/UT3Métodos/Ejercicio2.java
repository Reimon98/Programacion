package UT3Métodos;

public class Ejercicio2 {
	static int cubo (int num1)
	{
		return (num1*num1*num1);
	}

	public static void main(String[] args) {
		int num1;
		num1=3;
		int resultado;
		resultado=cubo(num1);
		System.out.println(resultado);

	}

}
