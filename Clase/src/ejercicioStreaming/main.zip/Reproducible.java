package ejercicioStreaming;

public interface Reproducible {
	void reproducir();
	void pausar ();
	TipoContenido obtenerTipoContenido();

}
