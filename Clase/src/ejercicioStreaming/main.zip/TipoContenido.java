package ejercicioStreaming;

public enum TipoContenido {
	MUSICA,
	PELICULA,
	SERIE,
	PODCAST,

}
