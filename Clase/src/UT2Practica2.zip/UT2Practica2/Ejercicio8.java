package UT2Practica2;
import java.util.Scanner;
public class Ejercicio8 {

	public static void main(String[] args) {
		String membresia;
		int num;
		Scanner entrada = new Scanner (System.in);
		System.out.println("Introduzca su tipo de membresía");
		membresia = entrada.next();
		switch (membresia) {
		case "A": System.out.println("Usted tiene un 30% de descuento"); break;
		case "B": System.out.println("Usted tiene un 20% de descuento"); break;
		case "C": System.out.println("Usted tiene un 10% de descuento"); break;
		default: System.out.println("Tipo de membresía inválido.");
		}
		
		
		
		
		
		

	}

}
