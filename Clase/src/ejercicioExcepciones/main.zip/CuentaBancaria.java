package ejercicioExcepciones;

public class CuentaBancaria {
	
	    private double saldo;

	    public CuentaBancaria(double saldoInicial) {
	        if (saldoInicial < 0) {
	            throw new IllegalArgumentException("El saldo inicial no puede ser negativo.");
	        }
	        this.saldo = saldoInicial;
	    }

	    public void depositar(double cantidad) {
	        if (cantidad < 0) {
	            throw new IllegalArgumentException("No se puede depositar una cantidad negativa.");
	        }
	        saldo += cantidad;
	    }

	    public void retirar(double cantidad) {
	        if (cantidad < 0) {
	            throw new IllegalArgumentException("No se puede retirar una cantidad negativa.");
	        }
	        if (cantidad > saldo) {
	            throw new IllegalArgumentException("Saldo insuficiente.");
	        }
	        saldo -= cantidad;
	    }

	    public double getSaldo() {
	        return saldo;
	    }
	}


