package ejercicioExcepciones;

public class main {

	public static void main(String[] args) {
		try {
            CuentaBancaria cuenta = new CuentaBancaria(100);
            cuenta.depositar(50);
            System.out.println("Depósito exitoso. Saldo actual: " + cuenta.getSaldo());
            cuenta.retirar(30);
            System.out.println("Retiro exitoso. Saldo actual: " + cuenta.getSaldo());
            cuenta.depositar(-10);
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }

        try {
            CuentaBancaria cuenta2 = new CuentaBancaria(50);
            cuenta2.retirar(100);
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }


	}


