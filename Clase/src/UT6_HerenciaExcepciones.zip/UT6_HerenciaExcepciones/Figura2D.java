package UT6_HerenciaExcepciones;

public abstract class Figura2D {
	private int numerolados;
	public Figura2D(int numerolados) {this.numerolados=numerolados;}
	public abstract double area();
	

}
