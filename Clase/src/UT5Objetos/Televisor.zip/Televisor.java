package UT5Objetos;

public class Televisor {
	private int canal;
	private int volumen;
	public Televisor () {canal = 1; volumen = 5;}
	public Televisor (int valorCanal) {
		setCanal (valorCanal);
	}
	public void subirCanal() {
		setCanal(canal+1);
		}
	public void bajarCanal() {
		setCanal(canal-1);
		}
	public void subirVolumen() {
		setVolumen(volumen+1);
		}
	public void bajarVolumen() {
		setVolumen(volumen-1);
		}
	public int getCanal() {return canal;}
	public void setCanal (int valorCanal) {
		if (valorCanal<1||valorCanal>=100) canal = 1;
		else canal = valorCanal;
		System.out.println("Canal: " +canal);
	}
	public void setVolumen (int valorVolumen) {
		if (valorVolumen<1||valorVolumen>=100) volumen = volumen;
		else volumen = valorVolumen;
		System.out.println("Volumen: " +volumen);
	}
	public String toString() {
		return "Canal: " +canal+ " Volumen: " +volumen;
	}

}
