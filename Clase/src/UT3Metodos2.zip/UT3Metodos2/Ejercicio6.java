package UT3Metodos2;
import java.util.Scanner;

public class Ejercicio6 {
	static boolean esNumeroValido (String texto) {
		try {
			Integer.parseInt(texto);
			return true;
		} catch (NumberFormatException e) {
			return false;
		}
	}

	public static void main(String[] args) {
		Scanner entrada = new Scanner (System.in);
		System.out.println("Introduzca un número");
		String cadena = entrada.next();
		boolean validar = esNumeroValido(cadena);
		if (validar) {
			System.out.println("Ha introducido un número");
		}else {
			System.out.println("Ha introducido caracteres que no son números");
		}
		

	}

}
